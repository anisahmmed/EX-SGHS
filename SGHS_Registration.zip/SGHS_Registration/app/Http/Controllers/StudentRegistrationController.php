<?php

namespace App\Http\Controllers;

use App\Models\students;
use Illuminate\Http\Request;
use shurjopayv2\ShurjopayLaravelPackage8\Http\Controllers\ShurjopayController;

class StudentRegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return 'Home';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('StudentRegistration.Create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        //dd($input);
        $fd = students::where('PhoneNumber','=',$input['PhoneNumber'])->first();
        //dd($fd);
        //
        if($fd==null)
        {
            $fileName="";
            if($request->hasFile('FilePath')){ 
                $fileName = $input['PhoneNumber'].".".$request->file('FilePath')->getClientOriginalExtension();
                //dd($fileName);
                echo $request->file('FilePath')->storeAs('Uploads',$fileName);
            }
            
            
            $input['FilePath'] = $fileName;
            $input['status'] = 0;
            $input['password'] =self::generate_password();
            students::create($input);
            $TotalAmount = $input['Amount'] + $input['AmountExt'];
            $fd2 = students::where('PhoneNumber','=',$input['PhoneNumber'])->first();
            //dd($fd2);
            $info = array( 
                'currency' => "BDT",
                'amount' => $TotalAmount, 
                'order_id' => (string)$fd2['id'], 
                'discsount_amount' =>0 , 
                'disc_percent' =>0 , 
                'client_ip' => "127.0.0.1", 
                'customer_name' => $fd2['FullName'], 
                'customer_phone' => $input['PhoneNumber'], 
                'email' => $input['Email'], 
                'customer_address' => $input['PresentAddress'], 
                'customer_city' => "Dhaka", 
                'customer_state' => "Dhaka", 
                'customer_postcode' => "1212", 
                'customer_country' => "BD",
                'value1' => "djkfhdukh",
            );
            //dd($info);
            $shurjopay_service = new ShurjopayController();
            return $shurjopay_service->checkout($info);

            //return redirect('Registration')->with('success', 'Contact Addedd!'); 
        }
        else{
            return redirect('Registration')->with('fail', 'Phone No already Used!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\students  $students
     * @return \Illuminate\Http\Response
     */
    public function show(students $students)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\students  $students
     * @return \Illuminate\Http\Response
     */
    public function edit(students $students)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\students  $students
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, students $students)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\students  $students
     * @return \Illuminate\Http\Response
     */
    public function destroy(students $students)
    {
        //
    }

    public function verifyPayment(Request $request)
    {
        $order_id = $request->order_id;
        $phone = $request->customer_phone;
        $shurjopay_service = new ShurjopayController();
        $data = $shurjopay_service->verify($order_id);
        //$student = students::find($request->order_id);
        // $student = students::where('id','=',$order_id)->first();
        // $student->status = 1;
        // $student->update();
        // $response = Http::get('http://test.com');
        return view('success_page');
        //return redirect('Registration')->with('PaymentSuccess', 'Payment Status: Success');
    }
    public function generate_password(){
        $length = 5;
        $chars =  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.
                  '0123456789`';
      
        $str = '';
        $max = strlen($chars) - 1;
      
        for ($i=0; $i < $length; $i++)
          $str .= $chars[random_int(0, $max)];
      
        return $str;
      }
}
