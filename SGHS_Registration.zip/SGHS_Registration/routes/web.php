<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\StudentRegistrationController;
 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
//Route::get('/', 'App\Http\Controllers\HomeController@Index');
//Route::get('/Home', 'App\Http\Controllers\HomeController@Index');
//Route::get('/Registration', 'App\Http\Controllers\StudentRegistrationController@create');
//Route::POST('/addStudent', 'App\Http\Controllers\StudentRegistrationController@store');


Route::get('/', [HomeController::class, 'Index']);
Route::get('/Home', [HomeController::class, 'Index']);
Route::get('/Registration', [StudentRegistrationController::class, 'create']);
Route::POST('/addStudent', [StudentRegistrationController::class, 'store']);

//Route::post('payment-gateway','App\Http\Controllers\PaymentGatewayController@initiatePayment');
Route::get('success-url','App\Http\Controllers\StudentRegistrationController@verifyPayment');