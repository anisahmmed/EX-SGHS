<!DOCTYPE html>
<html>
<head>
    <style>
        body{
            background-color: whitesmoke!important;
        }
    </style>
    <title>SGHS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</head>

<body>
<div class="col d-flex justify-content-center">
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top mx-auto order-0">
  

  <div class="collapse navbar-collapse nav justify-content-center" >
    <ul class="navbar-nav mr-auto" style="text-align:center;">
      <li class="nav-item active">
        <a class="nav-link" href="/Home">Home </span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/Registration">Registration</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#">Contuct Us</a>
      </li>
    </ul>
  </div>
</nav>
</div>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>

<?php /**PATH D:\New-xampp\htdocs\SGHS_Registration\resources\views/StudentRegistration/layout.blade.php ENDPATH**/ ?>