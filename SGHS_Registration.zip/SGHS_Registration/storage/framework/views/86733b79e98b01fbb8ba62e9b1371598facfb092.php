<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar-static-top/">

    <title>Shurjopay Payment Gateway Integration</title>

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/3.3/examples/navbar-static-top/navbar-static-top.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="https://getbootstrap.com/docs/3.3/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Static navbar -->
    <!-- <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Payment Gateway</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#login">Login</a></li>
            <li><a href="#signup">Sign Up</a></li>
          </ul>
        </div>
      </div>
    </nav> -->


    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
            <div class="card" style="margin:10%;">
                <div class="card-header">
                
                    <p style="font-size:25px;font-weight:bolder">
                        Payment Status : <b style="color:rgb(12, 116, 148);font-weight:bold">Success</b>
                    </p>
                    
                </div>

                <div class="card-body">

                    <div class="row">
                        <div class="col-md-3"></div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p style="font-size:20px;font-weight:bolder">Your payment process has been succeeded.</p>
                              
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p style="font-size:20px;font-weight:bolder">Redirect to Registration Page after 5 sec</p>
                              
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                    </div>
                    
                </div>
            </div>

    

        
      </div>

      

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="https://getbootstrap.com/docs/3.3/assets/js/ie10-viewport-bug-workaround.js"></script>
    <script type="text/JavaScript">
        // setTimeout(function () {
        //   $("#countdown").show(); 
        //   window.location.href = "/Registration"; //will redirect to your blog page (an ex: blog.html)
        // }, 5000);
        setTimeout(function () {
         // $("#countdown").show(); 
          window.location.href = "/Registration"; //will redirect to your blog page (an ex: blog.html)
        }, 5000);
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\SGHS_Registration\resources\views/success_page.blade.php ENDPATH**/ ?>