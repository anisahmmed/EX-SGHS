
<?php $__env->startSection('content'); ?>
<div style="margin-top: 20%;">
<div class="col d-flex justify-content-center">
    <div class="card col-md-12">
        <div class="card-header" style="text-align: center;"><h3>SGHS Student Registration</h3></div>
            <div class="card-body" style="background-color:aliceblue; text-align:center;">
                
                <button type="submit" class="btn btn-primary mybtn" data-target="/Registration">Registration</button>
            </div>
    </div>
</div>
</div>


<script>
    $('.mybtn').on('click', function(event) {
    event.preventDefault(); 
    var url = $(this).data('target');
    location.replace(url);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('StudentRegistration.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New-xampp\htdocs\SGHS_Registration\resources\views/Home/Index.blade.php ENDPATH**/ ?>